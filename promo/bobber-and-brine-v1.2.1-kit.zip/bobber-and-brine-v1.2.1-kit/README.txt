Bobber & Brine v1.2.1 - submission kit (EinarsGames)

bobber-and-brine-v1.2.1-game.zip   The game. HTML5, index.html at the root. Embed size 960 x 600.
                                   Saves with LocalStorage. Works on desktop and mobile.
screenshots/                       4 gameplay screenshots of v1.2.1 (1920 x 1200)
images/promo-1920x1080.png         v1.2 promo picture
images/icon-square-1024.png        Square icon
images/icon-wide-1280x720.png      Wide (16:9) icon

Play: https://einarsgames.itch.io/bobberbrine
